package main;

public enum Direction {
    left,
    right,
    up,
    down
}
