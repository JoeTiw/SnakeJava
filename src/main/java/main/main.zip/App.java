package main;

public class App {
    public static void main(String[] args) {
        Main.main(args);
    }
}
